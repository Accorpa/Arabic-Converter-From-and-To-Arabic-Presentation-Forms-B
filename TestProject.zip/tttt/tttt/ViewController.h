//
//  ViewController.h
//  tttt
//
//  Created by Accorpa LLC on 12/12/12.
//  Copyright (c) 2012 Accorpa LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (retain, nonatomic) IBOutlet UILabel *texter;
@end
