//
//  ViewController.m
//  tttt
//
//  Created by Accorpa LLC on 12/12/12.
//  Copyright (c) 2012 Accorpa LLC. All rights reserved.
//

#import "ViewController.h"
#import "ArabicConverter.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize texter;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    //Aref_Menna
    UIFont* font = [UIFont fontWithName:@"Aref_Menna" size:24];
    NSLog(@"%@",[font familyName]);
    [texter setFont:font];
    ArabicConverter* c = [[ArabicConverter alloc] init];
    NSString* s = [c convertArabic:@"وانه لعلي خلق عظيم "];
    [texter setText:s];
//    [texter setText:[c convertArabicBack:[texter text]]];
    [c release];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [texter release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setTexter:nil];
    [super viewDidUnload];
}
@end
